# portable-worker · 파일 handoff 계약 실습

## 목적

합성 요청 하나를 제출하고, 작업자가 선언된 입력 경계 안에서 처리해 terminal 응답을 보존하는 흐름을 확인합니다. 이 패키지는 운영용 Hermes 설치가 아니라 Python 표준 라이브러리만 사용하는 오프라인 계약 예제입니다.

## 저장소에서 실행

저장소 루트에서 다음 명령을 실행합니다.

```sh
make example NAME=portable-worker
```

## 내려받은 ZIP에서 실행

`examples.zip`을 풀고 `portable-worker` 디렉터리로 이동한 다음 실행합니다.

```sh
cd portable-worker
PYTHONPATH=src python3 -B -m unittest discover -s tests -v
```

`-B`는 Python bytecode 캐시 생성을 막습니다. 별도 패키지 설치, 네트워크, GPU, 자격 증명은 필요하지 않습니다.

## 검증 범위

테스트는 임시 디렉터리와 합성 입력만 사용합니다. 요청 ID 불변성·중복 제출, 원자적 파일 기록, terminal 응답 회수, 경로 traversal 및 symlink 차단, malformed request 차단, 실패/부분 산출물 보존 등 12개 계약을 확인합니다. 실제 사용자 자료나 외부 서비스와 연동하지 않으며, 실제 Hermes를 설치·구동하는 테스트도 아닙니다.

## 파일 구성

- `src/`: 저장소 `reference/`의 공용 요청 제출·작업 처리·파일 전송 모듈
- `tests/`: 저장소 `tests/test_contracts.py`의 합성 계약 테스트
- `README.md`: 이 오프라인 실행 안내

ZIP 안에서도 모듈은 `src/`, 테스트는 `tests/`에 놓입니다. 테스트는 실행 위치 기준으로 `src`를 Python import 경로에 사용합니다.
